import os
import base64
import re

CWD = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.join(CWD, 'public')

def file_to_base64(filepath, mime_type):
    with open(filepath, 'rb') as f:
        data = f.read()
    b64 = base64.b64encode(data).decode('ascii')
    return f"data:{mime_type};base64,{b64}"

print("1. Encoding assets to Base64...")

# 1. Matcaps
matcap_map = {}
matcap_dir = os.path.join(PUBLIC_DIR, 'resources', 'matcaps')
for fname in os.listdir(matcap_dir):
    if fname.endswith(('.jpg', '.jpeg', '.png')):
        ext = 'png' if fname.endswith('.png') else 'jpeg'
        rel_key = f"resources/matcaps/{fname}"
        matcap_map[rel_key] = file_to_base64(os.path.join(matcap_dir, fname), f"image/{ext}")
print(f"  Encoded {len(matcap_map)} matcaps.")

# 2. Alphas
alpha_map = {}
alpha_dir = os.path.join(PUBLIC_DIR, 'resources', 'alpha')
for fname in os.listdir(alpha_dir):
    if fname.endswith(('.jpg', '.jpeg', '.png')):
        ext = 'png' if fname.endswith('.png') else 'jpeg'
        alpha_map[fname] = file_to_base64(os.path.join(alpha_dir, fname), f"image/{ext}")
print(f"  Encoded {len(alpha_map)} alpha textures.")

# 3. Dropper & UV
dropper_path = os.path.join(PUBLIC_DIR, 'resources', 'dropper.png')
dropper_b64 = file_to_base64(dropper_path, 'image/png') if os.path.exists(dropper_path) else ''

uv_path = os.path.join(PUBLIC_DIR, 'resources', 'uv.png')
uv_b64 = file_to_base64(uv_path, 'image/png') if os.path.exists(uv_path) else ''

# 1x1 transparent PNG fallback for environments
dummy_env_b64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="

print("2. Reading CSS files...")
with open(os.path.join(PUBLIC_DIR, 'css', 'yagui.css'), 'r', encoding='utf-8') as f:
    yagui_css = f.read()

with open(os.path.join(PUBLIC_DIR, 'sculptris.css'), 'r', encoding='utf-8') as f:
    sculptris_css = f.read()

combined_css = f"/* YAGUI CSS */\n{yagui_css}\n\n/* SCULPTRIS CSS */\n{sculptris_css}"

print("3. Processing sculptgl.js...")
with open(os.path.join(PUBLIC_DIR, 'sculptgl.js'), 'r', encoding='utf-8') as f:
    sculptgl_js = f.read()

# Replace matcaps in sculptgl.js
for rel_path, b64 in matcap_map.items():
    sculptgl_js = sculptgl_js.replace(f'"{rel_path}"', f'"{b64}"')
    sculptgl_js = sculptgl_js.replace(f"'{rel_path}'", f"'{b64}'")

# Replace alpha loader in sculptgl.js
alpha_json = "{" + ", ".join([f'"{k}": "{v}"' for k, v in alpha_map.items()]) + "}"
sculptgl_js = sculptgl_js.replace(
    'i.src="resources/alpha/"+e[r]',
    'i.src=(window.__ALPHA_DATA__&&window.__ALPHA_DATA__[e[r]])||("resources/alpha/"+e[r])'
)

# Replace dropper
sculptgl_js = sculptgl_js.replace(
    'url(resources/dropper.png)',
    f'url({dropper_b64})'
)

# Replace UV texture
sculptgl_js = sculptgl_js.replace(
    '"resources/uv.png"',
    f'"{uv_b64}"'
)

# Replace environments with dummy 1x1
env_names = [
    "mpumalanga_veld_1k.png",
    "venetian_crossroads_1k.png",
    "moonless_golf_1k.png",
    "studio_small_01_1k.png",
    "winter_river_1k.png"
]
for env_name in env_names:
    sculptgl_js = sculptgl_js.replace(f'A+"{env_name}"', f'"{dummy_env_b64}"')
    sculptgl_js = sculptgl_js.replace(f'"{env_name}"', f'"{dummy_env_b64}"')

# Disable web workers in zip.js to make it 100% self-contained
sculptgl_js = sculptgl_js.replace('useWebWorkers:!0', 'useWebWorkers:!1')

print("4. Processing sculptris-ui.js...")
with open(os.path.join(PUBLIC_DIR, 'sculptris-ui.js'), 'r', encoding='utf-8') as f:
    sculptris_ui_js = f.read()

print("5. Processing index.html...")
with open(os.path.join(PUBLIC_DIR, 'index.html'), 'r', encoding='utf-8') as f:
    html = f.read()

# Replace CSS link tags with inline <style>
html = re.sub(r'<link\s+rel="stylesheet"\s+href="css/yagui\.css"[^>]*>', '', html)
html = re.sub(r'<link\s+rel="stylesheet"\s+href="sculptris\.css"[^>]*>', lambda _: f'<style>\n{combined_css}\n</style>', html)

# Replace matcap thumbnails with Base64 in HTML
for rel_path, b64 in matcap_map.items():
    html = html.replace(f'src="{rel_path}"', f'src="{b64}"')

# Replace script tags with inline <script>
script_block = f"""
  <script>
    window.__ALPHA_DATA__ = {alpha_json};
  </script>
  <script>
    {sculptgl_js}
  </script>
  <script>
    {sculptris_ui_js}
  </script>
"""

script_pattern = re.compile(r'<script\s+src="sculptgl\.js"></script>\s*<script\s+src="sculptris-ui\.js"></script>')
html = script_pattern.sub(lambda _: script_block, html)

out_root_html = os.path.join(CWD, 'index.html')
print(f"6. Writing single bundled HTML file: {out_root_html}...")
with open(out_root_html, 'w', encoding='utf-8') as f:
    f.write(html)

file_size_mb = os.path.getsize(out_root_html) / (1024 * 1024)
print(f"DONE! Standalone Single HTML Size: {file_size_mb:.2f} MB")

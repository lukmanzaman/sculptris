@echo off
title Sculptris Modern - Digital Sculpting Engine
cd /d "%~dp0"

:: Standalone Single HTML ready: langsung buka di browser default
if exist "%~dp0index.html" (
    start "" "%~dp0index.html"
    exit
)

:: Fallback Python server jika index.html root belum ada
python --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    python server.py
    exit
)

:: Fallback Node
npx -v >nul 2>&1
if %ERRORLEVEL% equ 0 (
    start http://localhost:8080/index.html
    npx http-server public -p 8080 -s
    exit
)

:: Fallback public folder
start "" "%~dp0public\index.html"
exit

const fs = require('fs');
const path = require('path');

const CWD = __dirname;
const PUBLIC_DIR = path.join(CWD, 'public');

function fileToBase64(filepath, mimeType) {
  const buf = fs.readFileSync(filepath);
  return `data:${mimeType};base64,${buf.toString('base64')}`;
}

console.log('1. Encoding assets to Base64...');

// 1. Matcaps
const matcapMap = {};
const matcapDir = path.join(PUBLIC_DIR, 'resources', 'matcaps');
fs.readdirSync(matcapDir).forEach(fname => {
  if (/\.(jpe?g|png)$/i.test(fname)) {
    const ext = fname.toLowerCase().endsWith('.png') ? 'png' : 'jpeg';
    const relKey = `resources/matcaps/${fname}`;
    matcapMap[relKey] = fileToBase64(path.join(matcapDir, fname), `image/${ext}`);
  }
});
console.log(`  Encoded ${Object.keys(matcapMap).length} matcaps.`);

// 2. Alphas
const alphaMap = {};
const alphaDir = path.join(PUBLIC_DIR, 'resources', 'alpha');
fs.readdirSync(alphaDir).forEach(fname => {
  if (/\.(jpe?g|png)$/i.test(fname)) {
    const ext = fname.toLowerCase().endsWith('.png') ? 'png' : 'jpeg';
    alphaMap[fname] = fileToBase64(path.join(alphaDir, fname), `image/${ext}`);
  }
});
console.log(`  Encoded ${Object.keys(alphaMap).length} alpha textures.`);

// 3. Dropper & UV
const dropperPath = path.join(PUBLIC_DIR, 'resources', 'dropper.png');
const dropperB64 = fs.existsSync(dropperPath) ? fileToBase64(dropperPath, 'image/png') : '';

const uvPath = path.join(PUBLIC_DIR, 'resources', 'uv.png');
const uvB64 = fs.existsSync(uvPath) ? fileToBase64(uvPath, 'image/png') : '';

// 1x1 transparent PNG fallback
const dummyEnvB64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

console.log('2. Reading CSS files...');
const yaguiCss = fs.readFileSync(path.join(PUBLIC_DIR, 'css', 'yagui.css'), 'utf-8');
const sculptrisCss = fs.readFileSync(path.join(PUBLIC_DIR, 'sculptris.css'), 'utf-8');
const combinedCss = `/* YAGUI CSS */\n${yaguiCss}\n\n/* SCULPTRIS CSS */\n${sculptrisCss}`;

console.log('3. Processing sculptgl.js...');
let sculptglJs = fs.readFileSync(path.join(PUBLIC_DIR, 'sculptgl.js'), 'utf-8');

// Replace matcaps in sculptgl.js
for (const [relPath, b64] of Object.entries(matcapMap)) {
  sculptglJs = sculptglJs.split(`"${relPath}"`).join(`"${b64}"`);
  sculptglJs = sculptglJs.split(`'${relPath}'`).join(`'${b64}'`);
}

// Replace alpha loader in sculptgl.js
const alphaJson = JSON.stringify(alphaMap);
sculptglJs = sculptglJs.replace(
  'i.src="resources/alpha/"+e[r]',
  'i.src=(window.__ALPHA_DATA__&&window.__ALPHA_DATA__[e[r]])||("resources/alpha/"+e[r])'
);

// Replace dropper
sculptglJs = sculptglJs.replace('url(resources/dropper.png)', `url(${dropperB64})`);

// Replace UV texture
sculptglJs = sculptglJs.replace('"resources/uv.png"', `"${uvB64}"`);

// Replace environments with dummy 1x1
const envNames = [
  'mpumalanga_veld_1k.png',
  'venetian_crossroads_1k.png',
  'moonless_golf_1k.png',
  'studio_small_01_1k.png',
  'winter_river_1k.png'
];
for (const envName of envNames) {
  sculptglJs = sculptglJs.split(`A+"${envName}"`).join(`"${dummyEnvB64}"`);
  sculptglJs = sculptglJs.split(`"${envName}"`).join(`"${dummyEnvB64}"`);
}

// Disable web workers in zip.js
sculptglJs = sculptglJs.replace('useWebWorkers:!0', 'useWebWorkers:!1');

console.log('4. Processing sculptris-ui.js...');
const sculptrisUiJs = fs.readFileSync(path.join(PUBLIC_DIR, 'sculptris-ui.js'), 'utf-8');

console.log('5. Processing index.html...');
let html = fs.readFileSync(path.join(PUBLIC_DIR, 'index.html'), 'utf-8');

// Replace CSS link tags with inline <style>
html = html.replace(/<link\s+rel="stylesheet"\s+href="css\/yagui\.css"[^>]*>/i, '');
html = html.replace(/<link\s+rel="stylesheet"\s+href="sculptris\.css"[^>]*>/i, `<style>\n${combinedCss}\n</style>`);

// Replace matcap thumbnails with Base64 in HTML
for (const [relPath, b64] of Object.entries(matcapMap)) {
  html = html.split(`src="${relPath}"`).join(`src="${b64}"`);
}

// Replace script tags with inline <script>
const scriptBlock = `
  <script>
    window.__ALPHA_DATA__ = ${alphaJson};
  </script>
  <script>
    ${sculptglJs}
  </script>
  <script>
    ${sculptrisUiJs}
  </script>
`;

html = html.replace(
  /<script\s+src="sculptgl\.js"><\/script>\s*<script\s+src="sculptris-ui\.js"><\/script>/i,
  scriptBlock
);

const outRootHtml = path.join(CWD, 'index.html');
console.log(`6. Writing single bundled HTML file: ${outRootHtml}...`);
fs.writeFileSync(outRootHtml, html, 'utf-8');

const fileSizeMb = (fs.statSync(outRootHtml).size / (1024 * 1024)).toFixed(2);
console.log(`DONE! Standalone Single HTML Size: ${fileSizeMb} MB`);
